package com.vibras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VibrasApplication {

	public static void main(String[] args) {
		SpringApplication.run(VibrasApplication.class, args);
	}

}
