package com.vibras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VibrasApplicationTests {

	@Test
	void contextLoads() {
	}

}
